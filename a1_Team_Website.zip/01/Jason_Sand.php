<!DOCTYPE html>
<html lang="en"> 
<head>
    <title><?php echo "Jason Sand's Resume"; ?></title>
    
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Jason Sand's resume">
    <meta name="author" content="Jason Sand">    
    <link rel="shortcut icon" href="favicon.ico"> 
    
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900" rel="stylesheet">
    
    <!-- FontAwesome JS-->
	<script defer src="assets/fontawesome/js/all.min.js"></script>
       
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="assets/css/pillar-1.css">


</head> 

<body>
    <article class="resume-wrapper text-center position-relative">
	    <div class="resume-wrapper-inner mx-auto text-start bg-white shadow-lg">
		    <header class="resume-header pt-4 pt-md-0">
			    <div class="row">
				    <div class="col-block col-md-auto resume-picture-holder text-center text-md-start">
				        <img class="picture" src="assets/images/JasonCropped.jpg" alt="">
				    </div><!--//col-->
				    <div class="col">
					    <div class="row p-4 justify-content-center justify-content-md-between">
						    <div class="primary-info col-auto">
							    <h1 class="name mt-0 mb-1 text-white text-uppercase text-uppercase"><?php echo 'Jason Sand'; ?></h1>
							    <div class="title mb-3"><?php echo "Head Penetration Tester"; ?></div>
							    <ul class="list-unstyled">
								    <li class="mb-2"><a class="text-link" href="#"><i class="far fa-envelope fa-fw me-2" data-fa-transform="grow-3"></i> <?php echo 'sandj3@mymail.nku.edu'; ?> </a></li>
								    <li><a class="text-link" href="#"><i class="fas fa-mobile-alt fa-fw me-2" data-fa-transform="grow-6"></i><?php echo '+1 859-982-5263'; ?></a></li>
							    </ul>
						    </div><!--//primary-info-->
						    <div class="secondary-info col-auto mt-2">
							    <ul class="resume-social list-unstyled">
					                <li class="mb-3"><a class="text-link" href="https://youtu.be/dQw4w9WgXcQ?si=bg5DiJsEfML0v-iW"><span class="fa-container text-center me-2"><i class="fab fa-linkedin-in fa-fw"></i></span><?php echo 'linkedin.com/in/sandj3'; ?></a></li>
					                <li class="mb-3"><a class="text-link" href="https://youtu.be/dQw4w9WgXcQ?si=bg5DiJsEfML0v-iW"><span class="fa-container text-center me-2"><i class="fab fa-github-alt fa-fw"></i></span><?php echo 'github.com/jjdasandman'; ?></a></li>
					                <li><a class="text-link" href="https://youtu.be/dQw4w9WgXcQ?si=bg5DiJsEfML0v-iW"><span class="fa-container text-center me-2"><i class="fas fa-globe"></i></span><?php echo 'dontclick.com'; ?></a></li>
							    </ul>
						    </div><!--//secondary-info-->
					    </div><!--//row-->
					    
				    </div><!--//col-->
			    </div><!--//row-->
		    </header>
		    <div class="resume-body p-5">
			    <section class="resume-section summary-section mb-5">
				    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Summary'; ?></h2>
				    <div class="resume-section-content">
					    <p class="mb-0">
						<?php echo "I'm a motivated full-time senior level Cybersecurity student with experience in security and threat management, eager to further develop my skills and expertise in Cybersecurity-related positions. Proficient in WireShark, debugging, SQL, and penetration testing, I also excel in network diagnostics, HTML, CSS, and Linux system configuration. Currently pursuing a Bachelor's degree in Cybersecurity with a Computer Science minor at Northern Kentucky University, I'm set to graduate in May 2024. "; ?></p>
				    </div>
			    </section><!--//summary-section-->
			    <div class="row">
				    <div class="col-lg-9">
					    <section class="resume-section experience-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Work Experience'; ?></h2>
						    <div class="resume-section-content">
							    <div class="resume-timeline position-relative">
								    <article class="resume-timeline-item position-relative pb-5">
									    
									    <div class="resume-timeline-item-header mb-2">
										    <div class="d-flex flex-column flex-md-row">
										        <h3 class="resume-position-title font-weight-bold mb-1"><?php echo 'Package Handler'; ?></h3>
										        <div class="resume-company-name ms-auto"><?php echo 'Fedex Ground'; ?></div>
										    </div><!--//row-->
										    <div class="resume-position-time"><?php echo '2021 - Present'; ?></div>
									    </div><!--//resume-timeline-item-header-->
									    <div class="resume-timeline-item-desc">
										    <p><?php echo "As a Package Handler at FedEx Ground, I collaborated seamlessly with fellow team members to expertly assemble, seal, and load packages into their designated trucks. My strong attention to detail ensured the accurate processing of shipments through careful label comprehension, minimizing distribution errors. In addition, I showcased my physical capabilities by effectively lifting and loading heavy packages alongside my teammates, contributing to efficient truck loading operations. This role underscored my dedication to precision, teamwork, and a commitment to streamlined package handling processes."; ?></p>
										    <h4 class="resume-timeline-item-desc-heading font-weight-bold">Achievements:</h4>
										    <p><?php echo 'Through dedicated contributions and a strong commitment to excellence, I have achieved several notable accomplishments during my tenure as a Package Handler at FedEx Ground.'; ?></p>
										    <ul>
											    <li><?php echo 'Efficiency Excellence: Consistently maintained a high level of productivity, exceeding daily package handling quotas showcasing dedication to efficient operations.'; ?></li>
											    <li><?php echo 'Shift Flexibility: Demonstrated adaptability by consistently volunteering and adapting to shift fluctuations during peak seasons'; ?></li>
											    <li><?php echo 'Continuous Improvement: Actively participated in daily team meetings and provided valuable suggestions for process enhancements'; ?></li>
											    <li><?php echo 'Big Boxer: consistantley showing physcial prowess and ability over other team members by lifting both greater weights and amounts.'; ?></li>
										    </ul>
										    <h4 class="resume-timeline-item-desc-heading font-weight-bold"><?php echo 'Technologies used:'; ?></h4>
										    <ul class="list-inline">
											    <li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo 'Handheld Scanners'; ?></span></li>
											    <li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo 'Conveyor Belt Systems'; ?></span></li>
											    <li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo 'Package Sorting Software'; ?></span></li>
											    <li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo 'Warehouse Management Systems'; ?></span></li>
											    <li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo 'Electronic Signature Capture Devices'; ?></span></li>
											    <li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo 'Computerized Tracking Systems'; ?></span></li>
										    </ul>
									    </div><!--//resume-timeline-item-desc-->

								    </article><!--//resume-timeline-item-->
								    
								    <article class="resume-timeline-item position-relative pb-5">
									    
									    <div class="resume-timeline-item-header mb-2">
										    <div class="d-flex flex-column flex-md-row">
										        <h3 class="resume-position-title font-weight-bold mb-1"><?php echo 'Line Cook'; ?></h3>
										        <div class="resume-company-name ms-auto"><?php echo 'LaRosas'; ?></div>
										    </div><!--//row-->
										    <div class="resume-position-time"><?php echo '2019 - 2021'; ?></div>
									    </div><!--//resume-timeline-item-header-->
									    <div class="resume-timeline-item-desc">
										    <p><?php echo "At LaRosa's Pizzeria in Cold Spring, KY, I took on a crucial role in maintaining efficient operations. As part of a fast-paced team, I excelled in relaying critical information to fellow team members, fostering seamless communication that was pivotal in ensuring the smooth flow of tasks. Moreover, I consistently demonstrated remarkable composure under high-stress environments, showcasing my ability to remain focused and effective even during intense situations. This proficiency not only contributed to a well-coordinated team effort but also played a significant role in upholding operational excellence at all times."; ?></p>
										    <h4 class="resume-timeline-item-desc-heading font-weight-bold">Achievements</h4>
										    <p><?php echo 'Service Excellence: Received consistent customer commendations for maintaining a positive demeanor and efficient service under pressure'; ?></p>
										    <h4 class="resume-timeline-item-desc-heading font-weight-bold">Technologies used:</h4>
										    <ul class="list-inline">
											    <li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo 'Point-of-Sale (POS) Systems'; ?></span></li>
											    <li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo 'Spatula'; ?></span></li>
											    <li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo 'Order Management Software'; ?></span></li>
											    <li class="list-inline-item"><span class="badge bg-secondary badge-pill"><?php echo 'Online Ordering Platforms'; ?></span></li>
											    </ul>
									    </div><!--//resume-timeline-item-desc-->

								    </article><!--//resume-timeline-item-->
								    							    
							    </div><!--//resume-timeline-->
							    
							    
							    
							    
							    
							    
						    </div>
					    </section><!--//projects-section-->
				    </div>
				    <div class="col-lg-3">
					    <section class="resume-section skills-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Skills &amp; Tools'; ?></h2>
						    <div class="resume-section-content">
						        <div class="resume-skill-item">
							        <ul class="list-unstyled mb-4">
								        <li class="mb-2">
								            <div class="resume-skill-name"><?php echo 'Javascript'; ?></div>
									        <div class="progress resume-progress">
											    <div class="progress-bar theme-progress-bar-dark" role="progressbar" style="width: 98%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
								        </li>
								        <li class="mb-2">
								            <div class="resume-skill-name"><?php echo 'HTML/CSS'; ?></div>
									        <div class="progress resume-progress">
											    <div class="progress-bar theme-progress-bar-dark" role="progressbar" style="width: 90%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
								        </li>
								        <li class="mb-2">
								            <div class="resume-skill-name"><?php echo 'Linux Configuration'; ?></div>
									        <div class="progress resume-progress">
											    <div class="progress-bar theme-progress-bar-dark" role="progressbar" style="width: 95%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
								        </li>
								        
								        <li class="mb-2">
								            <div class="resume-skill-name"><?php echo 'Wireshark'; ?></div>
									        <div class="progress resume-progress">
											    <div class="progress-bar theme-progress-bar-dark" role="progressbar" style="width: 92%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
								        </li>
								        <li class="mb-2">
								            <div class="resume-skill-name"><?php echo 'Metasploit'; ?></div>
									        <div class="progress resume-progress">
											    <div class="progress-bar theme-progress-bar-dark" role="progressbar" style="width: 89%" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
								        </li>
							        </ul>
						        </div><!--//resume-skill-item-->
						        <div class="resume-skill-item">
						            <h4 class="resume-skills-cat font-weight-bold"><?php echo 'Others'; ?></h4>
						            <ul class="list-inline">
							            <li class="list-inline-item"><span class="badge badge-light"><?php echo 'DevOps'; ?></span></li>
							            <li class="list-inline-item"><span class="badge badge-light"><?php echo 'Code Review'; ?></span></li>
							            <li class="list-inline-item"><span class="badge badge-light"><?php echo 'Git'; ?></span></li>
							            <li class="list-inline-item"><span class="badge badge-light"><?php echo 'Unit Testing'; ?></span></li>
							            <li class="list-inline-item"><span class="badge badge-light"><?php echo 'Wireframing'; ?></span></li>
							            <li class="list-inline-item"><span class="badge badge-light"><?php echo 'Sketch'; ?></span></li>
							            <li class="list-inline-item"><span class="badge badge-light"><?php echo 'Balsamiq'; ?></span></li>
							            <li class="list-inline-item"><span class="badge badge-light"><?php echo 'WordPress'; ?></span></li>
							            <li class="list-inline-item"><span class="badge badge-light"><?php echo 'Shopify'; ?></span></li>
						            </ul>
						        </div><!--//resume-skill-item-->
						    </div><!--resume-section-content-->
					    </section><!--//skills-section-->
					    <section class="resume-section education-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Education'; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled">
								    <li class="mb-2">
								        <div class="resume-degree font-weight-bold"><?php echo 'BSc in Cyber Security'; ?></div>
								        <div class="resume-degree-org"><?php echo 'Northern Kentucky University'; ?></div>
								        <div class="resume-degree-time"><?php echo '2020-2024'; ?></div>
								    </li>
								    <li>
								        <div class="resume-degree font-weight-bold"><?php echo 'High School Diploma'; ?></div>
								        <div class="resume-degree-org"><?php echo 'Campbell County High School'; ?></div>
								        <div class="resume-degree-time"><?php echo '2016 - 2020'; ?></div>
								    </li>
							    </ul>
						    </div>
					    </section><!--//education-section-->
					    <section class="resume-section reference-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Awards'; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled resume-awards-list">
								    <li class="mb-2 ps-4 position-relative">
								        <i class="resume-award-icon fas fa-trophy position-absolute" data-fa-transform="shrink-2"></i>
								        <div class="resume-award-name"><?php echo 'Founders Scholar'; ?></div>
								        <div class="resume-award-desc"><?php echo "The scholarship not only provides a monetary value but also reflects Northern Kentucky University's recognition of my dedication and commitment to excellence."; ?></div>
								    </li>
								    <li class="mb-0 ps-4 position-relative">
								        <i class="resume-award-icon fas fa-trophy position-absolute" data-fa-transform="shrink-2"></i>
								        <div class="resume-award-name"><?php echo 'KEES'; ?></div>
								        <div class="resume-award-desc"><?php echo 'Kentucky Educational Excellence Scholarship, or KEES, assists Kentucky students in paying for higher education.'; ?></div>
								    </li>
							    </ul>
						    </div>
					    </section><!--//interests-section-->
					    <section class="resume-section language-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Languages'; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled resume-lang-list">
								    <li class="mb-2"><span class="resume-lang-name font-weight-bold"><?php echo 'English'; ?></span> <small class="text-muted font-weight-normal"><?php echo '(Native)'; ?></small></li>
								    <li class="mb-2 align-middle"><span class="resume-lang-name font-weight-bold"><?php echo 'Spanish'; ?></span> <small class="text-muted font-weight-normal"><?php echo '(Professional)'; ?></small></li>
								    <li><span class="resume-lang-name font-weight-bold"><?php echo 'ASL'; ?></span> <small class="text-muted font-weight-normal"><?php echo '(Professional)';; ?></small></li>
							    </ul>
						    </div>
					    </section><!--//language-section-->
					    <section class="resume-section interests-section mb-5">
						    <h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3"><?php echo 'Interests'; ?></h2>
						    <div class="resume-section-content">
							    <ul class="list-unstyled">
								    <li class="mb-1"><?php echo 'Snow Skiing'; ?></li>
								    <li class="mb-1"><?php echo 'cars'; ?></li>
								    <li class="mb-1"><?php echo 'coding'; ?></li>
							    </ul>
						    </div>
					    </section><!--//interests-section-->
					    
				    </div>
			    </div><!--//row-->
				<section class="resume-section experience-section mb-5">
					<h2 class="resume-section-title text-uppercase font-weight-bold pb-3 mb-3">Projects'; ?></h2>
					<div class="row mt-4">
						<div class="col-md-4">
							<div class="card">
								<img src="assets/images/stangForSale.jpg" alt="Project 1" class="card-img-top">
								<div class="card-body">
									<h5 class="card-title"><?php echo 'Project 1'; ?></h5>
									<p class="card-text"><?php echo 'bought, built, n sell this bitch'; ?></p>
									<a href="https://www.instagram.com/2v.disgustang/" href="https://www.instagram.com/2v.disgustang/"><?php echo 'Go to link'; ?></a>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card">
								<img src="assets/images/meSki.jpg" alt="Project 2" class="card-img-top">
								<div class="card-body">
									<h5 class="card-title"><?php echo 'Project 2'; ?></h5>
									<p class="card-text"><?php echo 'Learn 2 ski with me'; ?></p>
									<a href="https://youtu.be/dQw4w9WgXcQ?si=_IKstsSxZ26hi1Sk" href="https://youtu.be/dQw4w9WgXcQ?si=_IKstsSxZ26hi1Sk"><?php echo 'Go to link'; ?></a>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card">
								<img src="assets/images/cobaltNbike.jpg" alt="Project 3" class="card-img-top">
								<div class="card-body">
									<h5 class="card-title"><?php echo 'Project 3'; ?></h5>
									<p class="card-text"><?php echo 'a bike and a cobalt rode into a barn...'; ?></p>
									<a href="https://youtu.be/dQw4w9WgXcQ?si=_IKstsSxZ26hi1Sk" href="https://youtu.be/dQw4w9WgXcQ?si=_IKstsSxZ26hi1Sk"><?php echo 'Go to link'; ?></a>
								</div>
							</div>
						</div>
					</div>
				</section><!--//projects-section-->
		    </div><!--//resume-body-->
		    
		    
	    </div>
    </article> 

    
    <footer class="footer text-center pt-2 pb-5">
	    <!--/* This template is free as long as you keep the footer attribution link. If you'd like to use the template without the attribution link, you can buy the commercial license via our website: themes.3rdwavemedia.com Thank you for your support. :) */-->
        <small class="copyright">Designed with <span class="sr-only">love</span><i class="fas fa-heart"></i><?php echo ' by Jason Sand'; ?></small>
    </footer>

    

</body>
</html> 

